<html>
	<head>
		<title><?= $title ?></title>
	</head>
	<body>
		
		<a href="<?php echo site_url('latihan')?>" title="Index">Index</a><br>
		<img src="<?php echo base_url('assets/img/vscode.png')?>" width="50px" alt="VS Code"><br>

		Note : <br>
		Jika membuat link gunakan site_url(),<br>
		Jika memanggil file gunakan base_url()<br> 
		

		Ini Halaman Edit<br>
	</body>
</html>